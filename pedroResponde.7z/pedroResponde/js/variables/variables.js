const apiURL = "https://api.openai.com/v1/chat/completions";
const apiKEY = "sk-proj-i30kte1WegqBn6QqRR9vT3BlbkFJedt0aEG52udRUxESW7AN";

export { apiURL, apiKEY };
// Define la URL de la API de OpenAI
const url = 'https://api.openai.com/v1/completions';

// Define el texto que quieres enviar a la API para generar una respuesta
const promptText = 'Hola';

// Define el cuerpo de la solicitud
const body = {
  model: 'text-davinci-002', // Modelo de lenguaje a utilizar
  prompt: promptText, // Texto para generar la respuesta
  max_tokens: 50, // Número máximo de tokens para generar en la respuesta
  temperature: 0.7 // Temperatura de muestreo para controlar la creatividad del modelo
};

// Realiza la petición a la API de OpenAI
fetch(url, {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer YOUR_API_KEY' // Reemplaza YOUR_API_KEY con tu propia API key
  },
  body: JSON.stringify(body)
})
  .then(response => response.json())
  .then(data => {
    // Maneja la respuesta de la API
    console.log(data);
  })
  .catch(error => {
    // Maneja los errores
    console.error('Error:', error);
  });
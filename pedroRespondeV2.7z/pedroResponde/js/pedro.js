const url = 'https://api.openai.com/v1/completions';

const promptText = 'Hola';

const body = {
  model: 'text-davinci-002',
  prompt: promptText,
  max_tokens: 50,
  temperature: 0.7 
};

fetch(url, {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer YOUR_API_KEY'
  },
  body: JSON.stringify(body)
})
  .then(response => response.json())
  .then(data => {
    console.log(data);
  })
  .catch(error => {
    console.error('Error:', error);
  });
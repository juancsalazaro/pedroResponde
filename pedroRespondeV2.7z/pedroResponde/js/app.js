const menuBtn = document.querySelector(".menu-btn");
var elemento = document.getElementById("navbar-cell");
elemento.style.display = "none";
menuBtn.addEventListener("click", function () {
  menuBtn.classList.toggle("open");
});


function toggleElemento() {
  if (elemento.style.display === "none") {
    elemento.style.display = "block";
  } else {
    elemento.style.display = "none";
  }
}

// const playSound = function() {
//     let element = document.createElement('div');
//     element.setAttribute('style', 'display: none');
//     element.innerHTML = `
//       <audio autoplay loop>
//         <source src="../assets/sonido1.mp3" type="audio/mpeg">
//       </audio>
//     `;
//     document.body.appendChild(element);
//     document.removeEventListener('click', playSound);
// }

// document.addEventListener('click', playSound);



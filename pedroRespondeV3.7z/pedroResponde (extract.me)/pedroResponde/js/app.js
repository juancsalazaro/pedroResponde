const login = false;

const menuBtn = document.querySelector(".menu-btn");
var elemento = document.getElementById("navbar-cell");
elemento.style.display = "none";
menuBtn.addEventListener("click", function () {
  menuBtn.classList.toggle("open");
});

function toggleElemento() {
  if (elemento.style.display === "none") {
    elemento.style.display = "block";
  } else {
    elemento.style.display = "none";
  }
}

var respuestaOculta = "";
var escribiendoRespuesta = false;
var fraseRespuesta = "Pedro, por favor responde esta pregunta importante";
var indexRespuesta = 0;

document
  .getElementById("solicitud")
  .addEventListener("keydown", function (event) {
    var key = event.key;
    if (!escribiendoRespuesta && key === ".") {
      escribiendoRespuesta = true;
    } else if (escribiendoRespuesta && key === ".") {
      escribiendoRespuesta = false;
    } else if (escribiendoRespuesta) {
      respuestaOculta += key;
      document.getElementById("solicitud").value = fraseRespuesta.substring(
        0,
        respuestaOculta.length + 1
      );
    }
  });

function hacerPregunta() {
  document.addEventListener("click", playSoundGolpe);
  var elementos = document.getElementsByClassName("none");
  for (var i = 0; i < elementos.length; i++) {
    elementos[i].style.display = "none";
  }
  document.getElementById("respuestaContainer").style.display = "flex";
  if (respuestaOculta === "") {
    respuestaOculta = "Algunas respuestas no deben de ser relevadas";
  }

  document.getElementById("respuestaPedro").innerText = respuestaOculta;
}

const playSoundFondo = function () {
  let element = document.createElement("div");
  element.setAttribute("style", "display: none");
  element.innerHTML = `
      <audio autoplay loop>
        <source src="../assets/sonido1.mp3" type="audio/mpeg">
      </audio>
    `;
  document.body.appendChild(element);
  document.removeEventListener("click", playSoundFondo);
};

document.addEventListener("click", playSoundFondo);

const playSoundGolpe = function () {
  let element = document.createElement("div");
  element.setAttribute("style", "display: none");
  element.innerHTML = `
    <audio autoplay>
      <source src="../assets/sonido2.mp3" type="audio/mpeg">
    </audio>
  `;
  document.body.appendChild(element);
  document.removeEventListener("click", playSoundGolpe);
};

if (login) {
  document.getElementById("iniciarSesionBtn").style.display = "none";
} else {
  document.getElementById("main").style.visibility = "hidden";
  document.getElementById("iniciarSesionBtn").style.display = "flex";
}

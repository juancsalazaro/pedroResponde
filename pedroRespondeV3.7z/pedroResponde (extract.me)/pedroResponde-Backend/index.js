// Importar las dependencias necesarias
const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 3000; // Puedes cambiar el puerto si es necesario
// Middleware para analizar JSON
app.use(express.json());
app.use(cors());
// Array para almacenar los usuarios
let usuarios = [];

// Endpoint para crear un nuevo usuario
app.post("/usuarios", (req, res) => {
  // Obtener los datos del cuerpo de la solicitud
  const {
    cedula,
    nombres,
    apellidos,
    direccion,
    telefono,
    correo,
    fechaNacimiento,
    username,
    password,
    tipoUsuario,
  } = req.body;

  // Validar que todos los campos necesarios estén presentes
  if (
    !cedula ||
    !nombres ||
    !apellidos ||
    !direccion ||
    !telefono ||
    !correo ||
    !fechaNacimiento ||
    !username ||
    !password ||
    !tipoUsuario
  ) {
    return res
      .status(400)
      .json({ mensaje: "Todos los campos son obligatorios" });
  }

  // Verificar si el usuario ya existe (usando el nombre de usuario como identificador único)
  const existeUsuario = usuarios.find(
    (usuario) => usuario.username === username
  );
  if (existeUsuario) {
    return res
      .status(400)
      .json({ mensaje: "El nombre de usuario ya está en uso" });
  }

  // Agregar el nuevo usuario al array de usuarios
  usuarios.push({
    cedula,
    nombres,
    apellidos,
    direccion,
    telefono,
    correo,
    fechaNacimiento,
    username,
    password, // En una aplicación real, deberías cifrar la contraseña antes de guardarla
    tipoUsuario,
  });

  // Devolver una respuesta de éxito
  res.status(201).json({ mensaje: "Usuario creado exitosamente" });
});

// Endpoint para el inicio de sesión
app.post("/login", (req, res) => {
  // Obtener los datos del cuerpo de la solicitud
  const { correo, password } = req.body;

  // Validar que se proporcionaron el correo y la contraseña
  if (!correo || !password) {
    return res
      .status(400)
      .json({ mensaje: "Correo electrónico y contraseña son obligatorios" });
  }

  // Buscar el usuario por su correo electrónico
  const usuario = usuarios.find((u) => u.correo === correo);

  // Verificar si se encontró un usuario con ese correo electrónico
  if (!usuario) {
    return res.status(401).json({ mensaje: "Credenciales incorrectas" });
  }

  // Verificar si la contraseña proporcionada coincide con la contraseña almacenada (en una aplicación real, deberías cifrar las contraseñas antes de guardarlas)
  if (usuario.password !== password) {
    return res.status(401).json({ mensaje: "Credenciales incorrectas" });
  }

  // Devolver una respuesta de éxito con los datos del usuario (sin incluir la contraseña)
  const usuarioSinContraseña = { ...usuario };
  delete usuarioSinContraseña.password;
  res.json({
    mensaje: "Inicio de sesión exitoso",
    usuario: usuarioSinContraseña,
  });
});

// Iniciar el servidor
app.listen(PORT, () => {
  console.log(`Servidor en funcionamiento en http://localhost:${PORT}`);
});
